 // printf("%d",account.account_number);
    // printf("%c",account.account_type);
    // printf("%d",demo.birth_year);
    // printf("%s\n",demo.country);
    // printf("%lf",demo.income);