#include<time.h>

#include <stdio.h>
// #include"commonHelpers.h"

int currentYear(void)
{ 
 time_t currentTime = time(NULL);
 return localtime(&currentTime)->tm_year + 1900;
}

void clearStandardInputBuffer(void)
{
 while (getchar() != '\n')
 {
 ; // On purpose: do nothing
 }
}


 int getInteger(void){
    char newLine='x';
    int value, keeptrying = 1,rc;
    
    do
    {
     rc=scanf("%d%c",&value,&newLine);      
    if(rc==0 || newLine!='\n'){
        printf("Value must be an integer\n");
        clearStandardInputBuffer();
       
    }else{
        keeptrying=0;
        
    }    
    } while (keeptrying==1);
    return value;
 } //end of getInteger

int getPositiveInteger(void){
 char newLine='x';
    int value, keeptrying = 1,rc;
    
    do
    {
     rc=scanf("%d%c",&value,&newLine);      
    if(rc==0 || newLine!='\n'){
        printf("Value must be a positive integer greater than zero\n");
        clearStandardInputBuffer();
       
    }else if(value<=0){
        printf("Value must be a positive integer greater than zero\n");
    }
    
    else{
        keeptrying=0;
       
    }    
    } while (keeptrying==1);
    return value;

} //end of postiveintegr methof

double getDouble(void){
    char newLine='x';
    double value;
    int  keeptrying = 1,rc;
    
    do
    {
     rc=scanf("%lf%c",&value,&newLine);      
    if(rc==0 || newLine!='\n'){
        printf("Value must be an double\n");
        clearStandardInputBuffer();
       
    }else{
        keeptrying=0;
       
    }    
    } while (keeptrying==1);
    return value;
 }// end of getdouble

double getPositiveDouble(){
char newLine='x';
double value;
    int keeptrying = 1,rc;
    
    do
    {
     rc=scanf("%lf%c",&value,&newLine);      
    if(rc==0 || newLine!='\n'){
        printf("Value must be a positive double greater than zero\n");
        clearStandardInputBuffer();
       
    }
    else if(value<=0){
        printf("Value must be a positive double greater than zero\n");
    }
    else{
        keeptrying=0;
        
    }    
    } while (keeptrying==1);
    return value;

}//end of getpositivedouble function

int getIntFromRange(int lower_bound, int upper_bound)
 {       char newLine='x';
         int value, keeptrying = 1, rc;
         

         do {
                 rc = scanf("%d%c", &value, &newLine);
                if(rc==0 || newLine!='\n'){
                printf("Value must be an integer\n");
                clearStandardInputBuffer();   
                }
                else if(value<lower_bound||value>upper_bound) {
                    printf("Value must be between %d and %d inclusive\n",lower_bound,upper_bound);
                }
                else{
                    keeptrying=0;
                    
                      }
         }//do end   
                    while (keeptrying == 1);

         return value;
 }

char getCharOption(char input[]){
    char newLine='x',value; 
     int i, keeptrying=1,rc;
    do
    {
      rc=scanf("%c%c",&value,&newLine);
      
      for ( i = 0; input[i]!='\0'; i++)
      {
         
         if(input[i]==value){  
          break;
      }
         
      }
      if(rc==0 || newLine!='\n'){
       printf("Character must be one of [ %s\n ]",input);
          clearStandardInputBuffer();
      }
      else if(input[i]==value ){
          keeptrying=0;
         
         
      }else{
           printf("Character must be one of [%s]\n",input);
      }
    
    }//do end
     while (keeptrying == 1);
   
     return value;
}

void getCString(char *ptr ,int lower_bound,int upper_bound){
    int keeptrying=1,length;
    char input [upper_bound+1];

    do
    {
     scanf("%s",input);
     for (int i = 0; input[i] !='\0'; i++)
     {
        length++;
     }
    //  printf("%d",length);
     if(lower_bound==upper_bound){
      if(length==lower_bound){
         
          keeptrying=0;
      }else {
          printf("String length must be exactly %d chars\n",lower_bound);
          length=0;
          clearStandardInputBuffer();
      }
     }
     else if(lower_bound==0 ){
         
        if(length<=upper_bound){
         
          keeptrying=0;
      }else {
          printf("String length must be no more than %d chars\n",upper_bound);
          length=0;
          clearStandardInputBuffer();
      }
     }
     else{
        if(length>=lower_bound &&length<=upper_bound){
          
          keeptrying=0;
      }else {
          printf("String length must be between %d and %d chars\n",lower_bound,upper_bound);
          length=0;
          clearStandardInputBuffer();
      }  
     }
    } while (keeptrying==1);
    
    for (int i=0;input[i]!='\0';i++)
    {
        *ptr=input[i];
        *ptr++;
       
    }
    

    
}



