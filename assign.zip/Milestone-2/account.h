struct Demographic{
    int birth_year;
    double income;
    char country[30];
} Demographic;

struct UserLogin{
    char name[30];
    char username[10];
    char password[8];
 
} UserLogin;
struct Account{
    int account_number;
    char account_type;

}Account;