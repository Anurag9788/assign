int currentYear(void);
void clearStanadardInputBuffer(void);
int getInteger(void);
int getPositiveInteger(void);
double getDouble();
double getPositiveDouble();
int getIntFromRange(int lower_bound,int upper_bound);
char getCharOption(char *str);
void getCString(char *ptr,int lower_bound,int upper_bound);

