// ===================================================================================
//  Assignment: 1 
//  Milestone : 2
// ===================================================================================
//  Student Name  : 
//  Student ID    : 
//  Student Email :
//  Course Section: 
// ===================================================================================
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

#include "account.h"                       
#include "commonHelpers.h"                  
#include"commonHelpers.c"
#include<string.h>

getAccount(struct Account *account){
   
    printf("Account Data: New Record\n");
    printf(" ----------------------------------------\n");
    printf("Enter the account number: ");
     
    account->account_number=getInteger();
    printf("Enter the account type (A=Agent | C=Customer)");
    char input[]="AC";
    account->account_type=getCharOption(input);

}
getDemographic(struct Demographic )

